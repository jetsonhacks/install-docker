# Iptable Raw Kernel Module

## Description
This package provides a pre-compiled Linux kernel module (`iptable_raw.ko`) sourced from the mainline Linux kernel. It’s offered as a convenience binary for systems where this in-tree module is not included or enabled by default.

### What the Module Does
The `iptable_raw` module is part of the Linux kernel's Netfilter framework. It enables raw packet processing by providing a table for manipulating packets before they enter the standard iptables processing chains. This is useful for advanced networking tasks like packet marking or dropping at an early stage.

## Requirements
- **Kernel Version**: Compiled for `5.15.148-tegra` (check your kernel with `uname -r` to confirm compatibility).
- **Root Access**: Required for installation (e.g., via `sudo`).
- **Target System**: Compatible with Linux systems running the specified kernel, such as NVIDIA Tegra-based devices.

## Files
- `iptable_raw.ko`: The pre-compiled kernel module.
- `install_module_iptable_raw.ko.sh`: Script to install and load the module.
- `LICENSE`: Licensing terms (GPL v2).

## Installation
1. **Download**:  
   Get `iptable_raw_module-1.0.tar.gz` and `iptable_raw_module-1.0.tar.gz.sha256`.
2. **Verify Integrity**:  
   Ensure the file is intact:  
   ```bash
   sha256sum -c iptable_raw_module-1.0.tar.gz.sha256
   ```
3. **Extract**:  
   Unpack the tarball:  
   ```bash
   tar -xzf iptable_raw_module-1.0.tar.gz
   ```
4. **Navigate**:  
   Move into the directory:  
   ```bash
   cd iptable_raw_module
   ```
5. **Run the Install Script**:  
   Execute with root privileges:  
   ```bash
   sudo ./install_module_iptable_raw.ko.sh
   ```  
   *Note*: If you see "permission denied," make it executable (rarely needed):  
   ```bash
   chmod +x install_module_iptable_raw.ko.sh
   ```

## Verification
Check if the module is loaded:  
```bash
lsmod | grep iptable_raw
```  
If `iptable_raw` appears, it’s active. Test with iptables rules using the raw table (e.g., `iptables -t raw -L`) or check `dmesg` for loading confirmation.

## Notes
- **Kernel Compatibility**: Built for `5.15.148-tegra`. It won’t work on other kernel versions without recompilation.
- **In-Tree Status**: The `iptable_raw` module is part of the mainline Linux kernel. This binary is for convenience on systems missing it.
- **Troubleshooting**:  
  - If `modprobe` fails, check `dmesg` for errors (e.g., version mismatch).  
  - Remove any existing `iptable_raw` module if needed:  
    ```bash
    sudo rmmod iptable_raw
    ```

## License
Distributed under the GNU General Public License v2 (see `LICENSE`), per Linux kernel requirements.

## Contact
For issues or requests (e.g., other kernel versions), https://github.com/jetsonhacks/jetson-orin-kernel-builder.
